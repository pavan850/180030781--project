package screens;
import screens.Welcome;

public class VirtualKeyApplication {

    public static void main(String[] args) {
    	
    	Welcome welcome = new Welcome();
    	welcome.introWS();
    	welcome.GetUserInput();

    }
}