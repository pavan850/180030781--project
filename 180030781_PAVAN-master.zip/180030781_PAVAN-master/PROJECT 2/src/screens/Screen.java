package screens;
public interface Screen {

    public void Show1();

    public void NavigateOption(int option);
    
    public void GetUserInput();

	public void Show();

}