package ccc;

public class String2 {
	public static void main(String args[]){  
		   String s1="Hanisha";  
		   String s2="Ponnuru";  
		   String s3=s1.concat(s2); 
		   
		   System.out.println(s3.toLowerCase());//Sachin Tendulkar  
		  }  
		}  
