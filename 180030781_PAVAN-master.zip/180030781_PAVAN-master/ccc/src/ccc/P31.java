package ccc;

public class P31 {
	public static void main(String[] args) {
		
		System.out.print(args[0]+" "+"Technologies"+" "+args[1]);

	}

}
