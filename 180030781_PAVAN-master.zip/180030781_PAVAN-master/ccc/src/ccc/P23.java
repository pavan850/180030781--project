package ccc;

class P23 {
    public static void main(String[] args) {
        int ascii[] = {65, 77, 111, 118, 101, 32, 89, 111, 117};
        for (int i = 0; i < ascii.length; i++) {
            System.out.print((char)ascii[i] + " ");
        }
        System.out.println();
    }
}