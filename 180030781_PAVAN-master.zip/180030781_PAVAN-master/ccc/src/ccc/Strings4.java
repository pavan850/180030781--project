package ccc;

import java.lang.*;
public class Strings4 {
public static void main(String[] args)
{
   String main_string = "Hanisha";    
   System.out.println(main_string.substring(0, main_string.length()/2));	
 } 
}